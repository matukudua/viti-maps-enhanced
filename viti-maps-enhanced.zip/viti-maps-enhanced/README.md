# Viti Maps Enhanced

**Prototype v0.2** – Interactive map platform for Fiji focused on villages, health facilities, towns, and future real-time layers (weather, satellite, Starlink, government projects).

Inspired by [Viti Maps](https://www.vitimaps.com/) and expanded with modern web mapping technology.

## Features (current)

- Interactive MapLibre GL map of Fiji
- **Hospitals** layer with major facilities (CWM, Lautoka, Labasa, etc.)
- **Towns & Cities** layer
- **Villages & Settlements** layer (expanded sample set, Starlink sites highlighted)
- Search box (type to find places)
- “Find nearest hospital to me” (uses browser geolocation)
- Layer toggles + legend
- Responsive sidebar (collapsible on mobile)
- Clean dark professional UI
- Data structure prepared for future live feeds

## Planned / Placeholder layers

- Weather (Himawari satellite + Fiji Met Service)
- Satellite imagery & change detection (Sentinel, Landsat, Google Earth Engine)
- Starlink coverage / community connectivity
- Government projects, organisations & alerts

See [`docs/DATA_STRUCTURE.md`](docs/DATA_STRUCTURE.md) for the full data model and integration plan.

## Quick start

1. Download or clone this folder.
2. Open `index.html` in a modern browser  
   (or serve it with any static file server, e.g. `npx serve .`).
3. Allow location access if you want the “nearest hospital” feature.

No build step required – pure HTML, CSS and JavaScript.

## Project structure

```
viti-maps-enhanced/
├── index.html              # Main application
├── css/
│   └── styles.css          # Professional dark theme
├── js/
│   └── app.js              # Map logic, search, nearest hospital
├── data/
│   ├── hospitals.json      # Hospital GeoJSON
│   ├── towns.json          # Towns & cities GeoJSON
│   └── villages.json       # Expanded village sample set
├── docs/
│   └── DATA_STRUCTURE.md   # Data model + future feed architecture
└── README.md
```

## Data notes

- Coordinates are approximate and for demonstration purposes.
- Production use requires cross-checking against official Fiji Government GIS, Ministry of Health, OpenStreetMap, geoBoundaries and other authoritative sources.
- Starlink-connected villages (e.g. Waivaka, Nasigatoka) are marked based on publicly reported Universal Service rollouts (2026).

## Next development steps

1. Replace sample data with complete authoritative datasets.
2. Add real weather tile layer (Himawari / Met Service).
3. Integrate satellite change-detection products.
4. Add offline support (Service Worker + cached tiles) for Starlink / limited-connectivity use.
5. Backend + PostGIS for dynamic updates and user corrections.
6. Mobile progressive web app (PWA) packaging.

## Credits & licence

- Map rendering: [MapLibre GL JS](https://maplibre.org/)
- Base map tiles: © OpenStreetMap contributors
- Concept inspired by the independent Viti Maps project
- This prototype is provided as open starting code.  
  Not affiliated with or endorsed by the Government of Fiji or any official agency.

---

Built as a rapid prototype – October 2026.
